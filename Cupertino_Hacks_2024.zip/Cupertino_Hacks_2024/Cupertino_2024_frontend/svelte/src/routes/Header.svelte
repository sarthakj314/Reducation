<script>
</script>

<nav class='w-[calc(100vw-1rem)] z-10 flex p-2 m-2 rounded-xl border-solid text-xl bg-neutral-800 font-bold'>
    <a href='/' class='text-red-700 italic px-2'>Red Bull</a>
    <a href='/about' class='text-white px-2'>About</a>
    <a href='/faq' class='text-white px-2'>FAQ</a>
    <div class='flex-grow'></div>
    <a href='/login' class='text-white px-2'>Login</a>
</nav>