<script>
	import '../app.css';
</script>

<div>

	<slot></slot>
	
</div>

<style>

</style>
