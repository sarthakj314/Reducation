<script>
// import { frontendPort, apiPort } from '../../constants.js'
const frontendPort = 5173
const apiPort = 5000
import History from '../../History.svelte'
import { onMount } from 'svelte';
export let data;

console.log(data.slug)

let C = null;
let MCQ = null;
let FRQ = null;
let YT = null;

let a = data.data.d;
console.log(a)
C = a['C'];
for (let [name, u] of Object.entries(C)) {
    u.expanded = false;
    for (let [name, sb] of Object.entries(u)) {
        sb = {name: sb, expanded: false};
    };
};
MCQ = a['MCQ'];
FRQ = a['FRQ'];
YT = a['YT'];

let loading = false;

function subunitChecker(e, mcq) {
    const formData = new FormData(e.target);
    const data = [...formData];
    let correct = (data[0][1] === mcq.options[mcq.ans])
    
    if (!correct) {
        document.getElementById(mcq.options[mcq.ans].replace(/\W/g, '')).parentNode.style.backgroundColor = "green";
        document.getElementById(data[0][1].replace(/\W/g, '')).parentNode.style.backgroundColor = "red";
    }
    if (correct) {
        document.getElementById(mcq.options[mcq.ans].replace(/\W/g, '')).parentNode.style.backgroundColor = "green";
    }

    return false;
}

function frqChecker(e, unit) {
    const formData = new FormData(e.target);
    const data = [...formData];
    console.log(data[0][1]);
    // const evaluation = fetch('api/blahblah')
    // frqs[unit.idx], data[0][1] is response (use apiPort)
    // document.getElementById(`p${frqs[unit.idx].replace(/\W/g, '')}`).innerText = evaluation;

    return false;
}
</script>

<div class='flex flex-row h-full'> 
    <History></History>
    <div class='w-[calc(100vw-260px)] bg-black/25 opacity-100 py-6 px-12'>
        {#if !loading}
            {#each C as [name, unit]}
                <button type='button' class='text-white opacity-87 text-left w-full text-xl' on:click={()=>{unit.expanded = !unit.expanded;}}>{name}</button>
                <div hidden={!unit.expanded}>
                    {#each unit as [sbname, subunit], idx}
                        <button type='button' class='text-white opacity-87 text-left w-full text-lg' on:click={()=>{subunit.expanded = !subunit.expanded;}}>{sbname}</button>
                        <div hidden={!subunit.expanded}>
                            <p class='text-white opacity-60 text-md'>Articles and whatever</p>
                            <iframe title='video' width="420" height="315"
                            src="https://www.youtube.com/embed/tgbNymZ7vqY">
                            </iframe>
                            {#each MCQ[name][idx].mcq as mcq}
                                <div>
                                    <h>{mcq.q}</h>
                                    <form on:submit={(e) => subunitChecker(e, mcq)}> 
                                        {#each mcq.options as opt}
                                        <div>
                                            <input id={opt.replace(/\W/g, '')} type="radio" name={mcq.q} value="{opt}" class='z-10'>
                                            <label for={opt.replace(/\W/g, '')}>{opt}</label>
                                            <br>
                                        </div>
                                        {/each}
                                        <input type='submit'>
                                    </form>
                                </div>
                            {/each}
                        </div>
                    {/each}
                    <div>
                        <form on:submit={(e) => frqChecker(e, unit)}>
                            <label for="{FRQ[name].replace(/\W/g, '')}">{FRQ[name]}</label>
                            <textarea id="{FRQ[name].replace(/\W/g, '')}" name='{FRQ[name]}'></textarea>
                            <input type='submit'>
                        </form>
                        <p id="p{FRQ[name].replace(/\W/g, '')}"></p>
                    </div>
                </div>
                <br>
            {/each}
        {:else}
                <p>loading data...</p>
        {/if}
    </div>
</div>

<style>
    :global(body) {
        background-color: #2f2f2f;
    }
</style>